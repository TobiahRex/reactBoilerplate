
.. |NamedType| replace:: OptionalNamedType

|NamedType|
------------------

.. autoclass:: pyasn1.type.namedtype.OptionalNamedType
   :members:

   .. note::

        The |NamedType| class models an optional field of a constructed ASN.1 type.
